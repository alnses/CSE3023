<%-- 
    Document   : mainPage
    Created on : 14 Apr 2026, 3:34:31 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Main Page</title>
        <style>
            .content-text {
                color: red;
                font-family: serif;
                width: 70%;
                margin: 20px auto;
                line-height: 1.5;
                text-align: left;
            }
            h1 { text-align: center; }
        </style>
    </head>
    <body>
        <%@include file="headerPage.jsp" %>

        
        <div class="content-text">
            Java Server Page (JSP) is a technology for controlling the content
            or appearance of Web pages through the use of servlets, small
            programs that are specified in the Web page and run on the Web server
            to modify the Web page before it is sent to the user who requested it.
        </div>
        
        <%@include file="footerPage.jsp" %>
    </body>
</html>
