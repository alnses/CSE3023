<%-- 
    Document   : processRegistration
    Created on : 14 Apr 2026, 3:52:27 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Process Registration Page</title>
    </head>
    <body>
        <%@include file="header.jsp" %>

        <%
            String name = request.getParameter("studentName");
            String matric = request.getParameter("matricNo");
            String club = request.getParameter("club");

            ArrayList<String[]> sessionMembers = (ArrayList<String[]>) session.getAttribute("memberList");
            if (sessionMembers == null) {
                sessionMembers = new ArrayList<String[]>();
            }

            if (name != null && !name.isEmpty()) {
                sessionMembers.add(new String[]{name, matric, club});
            }

            session.setAttribute("memberList", sessionMembers);
        %>

        <div style="padding: 20px;">
            <h2 style="color: green;">Registration Successful!</h2>
            <p><strong>Name:</strong> <%= name %></p>
            <p><strong>Matric:</strong> <%= matric %></p>
            <p><strong>Club:</strong> <%= club %></p>
            <hr>
            <a href="memberDirectory.jsp" style="padding: 10px; background: #004d40; color: white; text-decoration: none; border-radius: 5px;">View Member Directory</a>
            <br><br>
            <a href="registerClub.jsp">Register Another Student</a>
        </div>

        <%@include file="footer.jsp" %>
    </body>
</html>
