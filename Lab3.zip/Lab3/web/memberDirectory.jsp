<%-- 
    Document   : memberDirectory
    Created on : 14 Apr 2026, 3:57:14 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Member Directory Page</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <div style="padding: 20px;">
            <h2>Club Member Directory</h2>

            <table border="1" cellpadding="10" style="border-collapse: collapse; width: 100%;">
                <tr style="background-color: #f2f2f2;">
                    <th>Name</th><th>Matric</th><th>Club</th>
                </tr>
                <%
                    // Pull the list from the session
                    ArrayList<String[]> members = (ArrayList<String[]>) session.getAttribute("memberList");
                    
                    if (members != null) {
                        for(String[] member : members) { 
                %>
                <tr>
                    <td><%= member[0] %></td>
                    <td><%= member[1] %></td>
                    <td><%= member[2] %></td>
                </tr>
                <% 
                        } 
                    } else { 
                %>
                <tr>
                    <td colspan="3">No students registered yet.</td>
                </tr>
                <% } %>
            </table>
        </div>
        <%@include file="footer.jsp" %>
    </body>
</html>
