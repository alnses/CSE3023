<%-- 
    Document   : registerClub
    Created on : 14 Apr 2026, 3:52:12 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Registration Page</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <div style="padding: 20px;">
            <h2>Club Registration Form</h2>
            <form action="processRegistration.jsp" method="post">
                Student Name: <input type="text" name="studentName" required><br><br>
                Matric Number: <input type="text" name="matricNo" required><br><br>
                Selected Club: 
                <select name="club">
                    <option value="Computer Science Club">Computer Science Club</option>
                    <option value="Multimedia Club">Multimedia Club</option>
                    <option value="Robotics Club">Robotics Club</option>
                </select><br><br>
                <input type="submit" value="Register">
            </form>
        </div>
    <%@include file="footer.jsp" %>
    </body>
</html>
