<%-- 
    Document   : footer
    Created on : 14 Apr 2026, 3:50:46 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Footer Page</title>
    </head>
    <body>
        <hr>
        <div style="text-align: center; padding: 10px; font-size: 0.9em;">
            <p>&copy; 2026-Alin | Faculty of Computer Science and Mathematics, UMT</p>
        </div>
    </body>
</html>
