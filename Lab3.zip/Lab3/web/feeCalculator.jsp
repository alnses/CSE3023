<%-- 
    Document   : feeCalculator
    Created on : 14 Apr 2026, 3:56:57 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Fee Calculator</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <div style="padding: 20px;">
            <h2>Membership Fee Calculator</h2>
            <form method="get">
                Number of Activities joined: 
                <input type="number" name="activityCount" min="0">
                <input type="submit" value="Calculate Fee">
            </form>

            <%
                String count = request.getParameter("activityCount");
                if (count != null && !count.isEmpty()) {
                    int activities = Integer.parseInt(count);
                    double totalFee = activities * 10.00;
            %>
                <div style="margin-top: 20px; color: green; font-weight: bold;">
                    Total Fee to be paid: RM <%= String.format("%.2f", totalFee) %>
                </div>
            <% } %>
        </div>
        <%@include file="footer.jsp" %>
    </body>
</html>
