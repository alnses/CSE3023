<%-- 
    Document   : processCalculateCarLoan
    Created on : 14 Apr 2026, 3:06:42 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Car Loan Result</title>
        <style>
            .container {
                border: 1px solid #888;
                padding: 20px;
                width: 80%;
                margin-top: 10px;
            }
            .title-blue {
                color: blue;
                font-weight: bold;
                font-size: 1.5em;
                margin-bottom: 20px;
            }
            .data-row {
                margin: 15px 0;
                font-family: serif;
                font-size: 1.1em;
            }
        </style>
    </head>
    <body>
        <h2>Perform Car Loan Calculation</h2>

        <div class="container">
            <div class="title-blue">Details of car loan:</div>

            <%
                // Retrieve data from the HTML form
                String loanRequest = request.getParameter("loanAmount");
                String periodStr = request.getParameter("period");

                if (loanRequest != null && periodStr != null) {
                    try {
                        double principal = Double.parseDouble(loanRequest);
                        int years = Integer.parseInt(periodStr);

                        double interestRate = 0.045;
                        double totalInterest = principal * interestRate * years;
                        double totalLoan = principal + totalInterest;
            %>
                        <div class="data-row">
                            Loan Request : <%= principal %>
                        </div>
                        <div class="data-row">
                            Period of payment : <%= years %>
                        </div>
                        <div class="data-row">
                            Total Loan (+ interest) : <%= totalLoan %>
                        </div>
            <%
                    } catch (Exception e) {
                        out.println("Error in calculation: " + e.getMessage());
                    }
                }
            %>
        </div>

        <p>©2026-Alin</p>
    </body>
</html>