<%-- 
    Document   : headerPage.jsp
    Created on : 14 Apr 2026, 3:35:06 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Header Page</title>
    </head>
    <body>
        <div style="background-color: #fce4c4; padding: 10px; text-align: center; border: 1px solid #ddd; font-weight: bold; width: 80%; margin: 10px auto;">
            <h1>ABC Sdn Bhd</h1>
        </div>
    </body>
</html>
