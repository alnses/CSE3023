
<%-- 
    Document   : populateArray
    Created on : 14 Apr 2026, 2:51:14 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Salesman Data</title>
        <style>
            body { font-family: sans-serif; }
            
            table {
                border-collapse: collapse;
                width: 60%;
                margin-top: 20px;
                border: 1px solid #ddd;
            }
            
            th {
                background-color: #e3c56b; /* Gold/Yellowish header */
                color: black;
                padding: 12px;
                border: 1px solid #ccc;
            }
            
            td {
                padding: 10px;
                text-align: center;
                border: 1px solid #ccc;
            }
            tr:nth-child(even) { background-color: #f9f9f9; }
            tr:nth-child(odd) { background-color: #fffdf5; }
            
        </style>
    </head>
    <body>
        <h2>Read Java array and populate it into HTML table.</h2>
        
        <%
            String[][] salesData = {
                {"Salesman 1", "2500", "2100", "2200"},
                {"Salesman 2", "2000", "1900", "2400"},
                {"Salesman 3", "1800", "2200", "2450"}
            };
        %>
        
        <table>
            <thead>
                <tr>
                    <th>Salesman</th>
                    <th>Jan</th>
                    <th>Feb</th>
                    <th>Mac</th>
                </tr>
            </thead>
            <tbody>
                <% 
                
                    for (int i = 0; i < salesData.length; i++) { 
                %>
                <tr>
                    <% 
                 
                        for (int j = 0; j < salesData[i].length; j++) { 
                    %>
                        <td><%= salesData[i][j] %></td>
                    <% 
                        } 
                    %>
                </tr>
                <% 
                    } 
                %>
            </tbody>
        </table>
    </body>
    &copy;2026-Alin
</html>
