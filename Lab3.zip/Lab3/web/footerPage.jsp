<%-- 
    Document   : footerPage.jsp
    Created on : 14 Apr 2026, 3:37:42 pm
    Author     : ACER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Footer Page</title>
    </head>
    <body>
        <div style="background-color: #fce4c4; padding: 1px; text-align: center; border: 1px solid #ddd; width: 80%; margin: 10px auto;">
            <center>
                <p>&copy; 2026-Alin</p>
            </center>  
        </div>
    </body>
</html>
