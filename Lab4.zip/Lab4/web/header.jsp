<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>UMT BMI System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h2>Healthy Lifestyle Awareness Program</h2>
    <div>
        <a href="bmiCalculator.jsp">BMI Calculator</a>
        <a href="resultBMI.jsp">Result</a>
        <a href="healthInfo.jsp">Health Info</a>
    </div>
</div>

<div class="container">