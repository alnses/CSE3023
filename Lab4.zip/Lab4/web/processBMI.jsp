<%
double weight = 0;
double height = 0;

try {
    weight = Double.parseDouble(request.getParameter("weight"));
    height = Double.parseDouble(request.getParameter("height"));
} catch(Exception e) {}

if(height == 0){
    response.sendRedirect("bmiCalculator.jsp");
    return;
}

double bmi = weight / (height * height);

String category;

if (bmi < 18.5)
    category = "Underweight";
else if (bmi <= 25)
    category = "Normal";
else
    category = "Overweight";
%>

<jsp:forward page="resultBMI.jsp">
    <jsp:param name="bmi" value="<%= bmi %>" />
    <jsp:param name="category" value="<%= category %>" />
</jsp:forward>