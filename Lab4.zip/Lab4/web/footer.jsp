</div>

<footer style="text-align:center; padding:20px; color:#555;">
    � 2026 Faculty of Computer Science and Mathematics, UMT
</footer>

</body>
</html>