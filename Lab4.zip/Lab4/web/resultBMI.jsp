<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
String bmiValue = request.getParameter("bmi");
String category = request.getParameter("category");
%>

<%@ include file="header.jsp" %>

<div class="card">
    <div class="form-title">BMI Result</div>

<%
if (bmiValue == null || category == null) {
%>

    <p>No result available. Please calculate BMI first.</p>

    <button class="btn" onclick="location.href='bmiCalculator.jsp'">
        Go to Calculator
    </button>

<%
} else {
%>

    <div class="result-group">
        <label>Your BMI:</label>
        <p><%= String.format("%.2f", Double.parseDouble(bmiValue)) %></p>
    </div>

    <div class="result-group">
        <label>Category:</label>
        <p><%= category %></p>
    </div>

    <button class="btn" onclick="location.href='bmiCalculator.jsp'">
        Back
    </button>

<%
}
%>

</div>

<%@ include file="footer.jsp" %>