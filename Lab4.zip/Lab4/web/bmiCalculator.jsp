<%@ include file="header.jsp" %>

<div class="card">
    <div class="form-title">BMI Calculator</div>

    <form action="processBMI.jsp" method="post">

        <div class="form-group">
            <label>Weight (kg)</label>
            <input type="number" step="0.1" name="weight" required>
        </div>

        <div class="form-group">
            <label>Height (m)</label>
            <input type="number" step="0.01" name="height" required>
        </div>

        <button type="submit" class="btn">Calculate BMI</button>
    </form>
</div>

<%@ include file="footer.jsp" %>