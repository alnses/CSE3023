<%@ page import="java.util.ArrayList" %>
<%@ include file="header.jsp" %>

<%
ArrayList<String[]> bmiList = new ArrayList<>();

bmiList.add(new String[]{"< 18.5", "Underweight"});
bmiList.add(new String[]{"18.5 - 25", "Normal"});
bmiList.add(new String[]{"> 25", "Overweight"});
%>

<div class="card">
    <div class="form-title">BMI Health Information</div>

    <table>
        <tr>
            <th>BMI Range</th>
            <th>Category</th>
        </tr>

        <%
        for(String[] row : bmiList){
        %>
        <tr>
            <td><%= row[0] %></td>
            <td><%= row[1] %></td>
        </tr>
        <%
        }
        %>
    </table>
</div>

<%@ include file="footer.jsp" %>